<div class="row">
  <div class="col-md-2 mb-3">
      <a href="{{$btnLink}}"><button class="btn btn-sm btn-primary"> <i class="feather icon-corner-down-left"></i>{{$btnText}}</button></a>
  </div>
</div>