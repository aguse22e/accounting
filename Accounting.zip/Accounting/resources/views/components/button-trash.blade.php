<div class="row">
    <div class="col-md-2 mb-3">
        <a href="{{ $btnTrashLink }}"><button class="btn btn-sm btn-warning"> <i class="ti-trash"></i>{{ $btnTrashText }}</button></a>
    </div>
</div>
