<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('components.page-header', [
    'pageTitle' => $pageTitle,
    'pageSubtitle' => '',
    'pageIcon' => $pageIcon,
    'parentMenu' => $parentMenu,
    'current' => $current
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('components.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('components.button-add', ['btnText' => $btnText, 'btnLink' => $btnLink], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::segment(1) == 'supplier' ? 'active' : ''); ?>" href="<?php echo e(url('/supplier')); ?>">List Supplier</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::segment(2) == 'trash' ? 'active' : ''); ?>" href="<?php echo e(url('/supplier/trash')); ?>">Tempat Sampah</a>
        </li>
    </ul>
    <div class="card">
        <div class="card-header">

            <h5>List Supplier</h5>
            <div class="col-md-4 pull-right">
                <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
        <div class="card-block table-border-style">
            <?php echo $__env->make('pages.supplier._table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Accounting\resources\views/pages/supplier/index.blade.php ENDPATH**/ ?>