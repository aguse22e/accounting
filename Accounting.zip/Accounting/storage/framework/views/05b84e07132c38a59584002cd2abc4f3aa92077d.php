<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="<?php echo e($pageIcon); ?> bg-c-blue"></i>
                <div class="d-inline">
                    <h5><?php echo e($pageTitle); ?></h5>
                    <?php if(isset($pageSubtitle)): ?>
                        <span><?php echo e($pageSubtitle); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb breadcrumb-title">

                    <li class="breadcrumb-item">
                        <a href="<?php echo e($parentMenu ? $parentMenu : '#'); ?>"><i class="<?php echo e($pageIcon); ?>"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!"><?php echo e($current); ?></a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Compressed\accounting-main\accounting-main\resources\views/components/page-header.blade.php ENDPATH**/ ?>