<form action="<?php echo e(url('general-ledger/neraca-saldo')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">

        <div class="col-md-4 mb-4">
            <label for="">Kode Akun</label>
            <select name="kodeAkun[]" class="js-example-basic-multiple col-sm-12" style="width: 100%;" multiple required>
                <option value="">--Pilih Akun--</option>
                <option value="all" <?php echo e($isAll ? 'selected' : ''); ?>>Semua Akun</option>
                <?php $__currentLoopData = $allAkun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->kode_akun); ?>" <?php echo e(isset($kodeAkun) && !$isAll && in_array($item->kode_akun, $selectedAkun) ? 'selected' : ''); ?> ><?php echo e($item->kode_akun . ' ~ '.$item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-3 mb-4">
            <label for="">Dari</label>
            <input type="date" name="tanggalDari" autocomplete="off" class="form-control form-control-lg" value="<?php echo e(isset($dari) ? $dari : date('Y-m-d')); ?>" required>
        </div>

        <div class="col-md-3 mb-4">
            <label for="">Sampai</label>
            <input type="date" name="tanggalSampai" autocomplete="off" class="form-control form-control-lg" value="<?php echo e(isset($sampai) ? $sampai : date('Y-m-d')); ?>" required>
        </div>

        <div class="col-md-2 mt-4">
            <button type="submit" class="btn btn-primary"> <i class="fas fa-filter"></i> Filter</button>
        </div>

    </div>
</form>
<?php /**PATH C:\laragon\www\Accounting\resources\views/pages/general-ledger/neraca-saldo/_form-filter.blade.php ENDPATH**/ ?>